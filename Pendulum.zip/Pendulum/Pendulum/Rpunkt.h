#pragma once
#include<cmath>
ref class Ppunkt;
ref class Rpunkt {
	public:
	Rpunkt(){}
	Rpunkt(double x, double y):
		xx(x), yy(y){}
	double returnxx() { return xx; }
	double returnyy() { return yy; }
	Rpunkt(Ppunkt^ obj) {
		//radianer = grader * PI / 180.0;
		double rad = obj->ra() * (PI / 180.0);
		xx = obj->rd() * cos(rad);
		yy = obj->rd() * sin(rad);
	}
	void getPpunkt(Ppunkt^ pp) {
		//radianer = grader * PI / 180.0;
		double rad = pp->ra() * (PI / 180.0);
		xx = pp->rd() * cos(rad);
		yy = pp->rd() * sin(rad);

	}
private:
	double xx;
	double yy;
	const double PI = 3.14159265;

};