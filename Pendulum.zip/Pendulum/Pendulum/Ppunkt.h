#pragma once
ref class Ppunkt {
public:
	Ppunkt(){}
	Ppunkt(double d, double a):
		dist(d), angle(a)
	{}
	double rd() { return dist; }
	double ra() { return angle; }
	void setRpunkt(double d, double a){
		dist = d;
		angle = a;
	}
private:
	double dist;
	double angle;
};