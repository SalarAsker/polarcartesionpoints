#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThread]//leave this as is
int main(array<String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Pendulum::MyForm form; //projekt1 ska vara namn p� ditt projekt och
						   //MyForm ska vara namn ditt from
	Application::Run(%form);
	return 0;
}

